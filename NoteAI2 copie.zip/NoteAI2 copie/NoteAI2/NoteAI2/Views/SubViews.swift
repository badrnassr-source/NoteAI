import SwiftUI
import Combine
// ==========================================
// 1. LE FLUX D'ONBOARDING COMPLET (SCREENS 1 À 5)
// ==========================================
struct OnboardingFlow: View {
    var onCompletion: () -> Void
    @State private var currentTab = 0
    
    var body: some View {
        ZStack {
            // Fond dégradé très doux et lumineux
            LinearGradient(
                colors: [Color(red: 0.96, green: 0.97, blue: 0.99), .white],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            TabView(selection: $currentTab) {
                // Écran 1 : Welcome
                OnboardingStepView(
                    imageName: "glass_sphere_welcome",
                    imageSize: 160,
                    title: "Note AI",
                    subtitle: "Your thoughts, structured by\npremium intelligence.",
                    showButton: true,
                    buttonText: "Get Started",
                    caption: "Refined simplicity for high performance",
                    action: { nextTab() }
                )
                .tag(0)
                
                // Écran 2 : Capture Everything
                OnboardingStepView(
                    imageName: "glass_cards_capture",
                    imageSize: 180,
                    badgeText: "LISTENING...",
                    title: "Capture Everything.",
                    subtitle: "Voice, text, or images. Our AI summarizes and categorizes your data into refined, actionable insights automatically.",
                    showButton: true,
                    buttonText: "Continue",
                    action: { nextTab() }
                )
                .tag(1)
                
                // Écran 3 : Organized by Intelligence
                OnboardingStepView(
                    imageName: "glass_folders_organization",
                    imageSize: 180,
                    title: "Organized by\nIntelligence",
                    subtitle: "Forget manual folders. AI instantly structures your chaotic thoughts into a beautiful, searchable library of knowledge.",
                    showButton: true,
                    buttonText: "Continue",
                    action: { nextTab() }
                )
                .tag(2)
                
                // Écran 4 : Elite Thinkers + Témoignage
                OnboardingStepView(
                    imageName: "glass_spheres_cluster",
                    imageSize: 170,
                    title: "Join the Elite Thinkers",
                    subtitle: "", // Remplacé par la carte témoignage personnalisée ci-dessous
                    showButton: true,
                    buttonText: "Ready to Start",
                    customContent: AnyView(
                        VStack(spacing: 12) {
                            // Badge Utilisateurs
                            HStack(spacing: -6) {
                                ForEach(0..<3) { i in
                                    Image(systemName: "person.crop.circle.fill")
                                        .resizable()
                                        .frame(width: 24, height: 24)
                                        .foregroundColor(.gray.opacity(0.4))
                                        .background(Circle().fill(.white))
                                }
                                Text("50K+ POWER USERS")
                                    .font(.system(size: 10, weight: .bold))
                                    .foregroundColor(.secondary)
                                    .padding(.leading, 8)
                            }
                            
                            // Bulle de citation
                            VStack(alignment: .leading, spacing: 6) {
                                Text("\"The first app that actually feels as fast as my thoughts. Note AI is indispensable.\"")
                                    .font(.system(size: 13, weight: .medium))
                                    .italic()
                                    .foregroundColor(.primary)
                                Text("- JOHN K., PRODUCT DESIGNER")
                                    .font(.system(size: 9, weight: .bold))
                                    .foregroundColor(.secondary)
                            }
                            .padding(16)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(16)
                            .shadow(color: Color.black.opacity(0.04), radius: 8, x: 0, y: 4)
                        }
                        .padding(.horizontal, 30)
                    ),
                    action: { nextTab() }
                )
                .tag(3)
                
                // Écran 5 : Paywall Note AI Premium
                PaywallView(onDismiss: onCompletion)
                    .tag(4)
            }
            .tabViewStyle(.page(indexDisplayMode: .never)) // On gère l'indicateur nous-mêmes
            
            // Indicateurs de progression (petits points) en haut, sauf pour le paywall
            if currentTab < 4 {
                VStack {
                    HStack(spacing: 6) {
                        ForEach(0..<4) { index in
                            Circle()
                                .fill(currentTab == index ? Color.primary : Color.primary.opacity(0.15))
                                .frame(width: 5, height: 5)
                        }
                    }
                    .padding(.top, 70)
                    Spacer()
                }
            }
        }
    }
    
    private func nextTab() {
        withAnimation(.easeInOut(duration: 0.4)) {
            currentTab += 1
        }
    }
}

// Composant réutilisable pour chaque étape d'onboarding
struct OnboardingStepView: View {
    let imageName: String
    let imageSize: CGFloat
    var badgeText: String? = nil
    let title: String
    let subtitle: String
    var showButton = false
    var buttonText = ""
    var caption: String? = nil
    var customContent: AnyView? = nil
    var action: () -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            Spacer()
            
            // Visuel 3D
            Image(imageName)
                .resizable()
                .scaledToFit()
                .frame(width: imageSize, height: imageSize)
                .shadow(color: Color.black.opacity(0.05), radius: 15, x: 0, y: 10)
                .padding(.bottom, 30)
            
            // Badge optionnel (comme le "Listening...")
            if let badgeText = badgeText {
                Text(badgeText)
                    .font(.system(size: 9, weight: .bold))
                    .tracking(1)
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Capsule().fill(Color.black.opacity(0.03)))
                    .padding(.bottom, 15)
            }
            
            // Titre Principal
            Text(title)
                .font(.system(size: 30, weight: .semibold, design: .serif))
                .multilineTextAlignment(.center)
                .foregroundColor(.primary)
                .padding(.horizontal, 24)
            
            // Description / Contenu customisé
            if let customContent = customContent {
                customContent
                    .padding(.top, 16)
            } else {
                Text(subtitle)
                    .font(.system(size: 14))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .lineSpacing(5)
                    .padding(.horizontal, 40)
                    .padding(.top, 16)
            }
            
            Spacer()
            
            // Bouton d'action principal
            if showButton {
                Button(action: action) {
                    Text(buttonText)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(buttonText == "Get Started" ? .primary : Color(.systemBackground))
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(
                            Capsule()
                                .fill(buttonText == "Get Started" ? Color.white : Color.primary)
                                .shadow(color: Color.black.opacity(buttonText == "Get Started" ? 0.04 : 0.1), radius: 8, x: 0, y: 4)
                        )
                        .overlay(
                            Capsule().stroke(Color.primary.opacity(buttonText == "Get Started" ? 0.08 : 0), lineWidth: 1)
                        )
                }
                .padding(.horizontal, 24)
            }
            
            // Sous-titre décoratif tout en bas (comme sur l'écran 1)
            if let caption = caption {
                Text(caption)
                    .font(.system(size: 11))
                    .foregroundColor(.secondary.opacity(0.7))
                    .padding(.top, 16)
                    .padding(.bottom, 12)
            } else {
                Spacer().frame(height: 50)
            }
        }
    }
}

// ==========================================
// 2. L'ÉCRAN DE PAYWALL DE L'APP (SCREEN 5)
// ==========================================
struct PaywallView: View {
    var onDismiss: () -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            // Header de fermeture et compteur
            HStack {
                Button(action: onDismiss) {
                    Image(systemName: "xmark")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.secondary)
                        .frame(width: 30, height: 30)
                        .background(Circle().fill(Color.black.opacity(0.03)))
                }
                Spacer()
                Text("EARLY ADOPTER OFFER: 24H LEFT")
                    .font(.system(size: 9, weight: .bold))
                    .tracking(0.5)
                    .foregroundColor(.amberDark)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.amberLight)
                    .cornerRadius(20)
            }
            .padding(.horizontal, 20)
            .padding(.top, 20)
            
            Spacer()
            
            // Image 3D Cristal
            Image("crystal_premium")
                .resizable()
                .scaledToFit()
                .frame(width: 140, height: 140)
                .shadow(color: Color.black.opacity(0.05), radius: 15, x: 0, y: 8)
                .padding(.bottom, 24)
            
            // Titres
            Text("Note AI Premium")
                .font(.system(size: 28, weight: .semibold, design: .serif))
                .foregroundColor(.primary)
            
            Text("Unleash the full potential of your mind.")
                .font(.system(size: 13))
                .foregroundColor(.secondary)
                .padding(.top, 6)
                .padding(.bottom, 30)
            
            // Liste des Avantages Premium
            VStack(alignment: .leading, spacing: 18) {
                PaywallFeatureRow(icon: "sparkles", text: "Unlimited & Smart Summarization")
                PaywallFeatureRow(icon: "arrow.triangle.2.circlepath", text: "Cross-Device Real-Time Cloud Sync")
                PaywallFeatureRow(icon: "magnifyingglass", text: "Priority Semantic Search & Filters")
            }
            .padding(.horizontal, 30)
            
            Spacer()
            
            // Plan tarifaire
            HStack {
                Text("Annual Plan")
                    .font(.system(size: 14, weight: .bold))
                Spacer()
                Text("$4.99")
                    .font(.system(size: 16, weight: .bold))
                Text("/month")
                    .font(.system(size: 12))
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)
            .background(RoundedRectangle(cornerRadius: 18).stroke(Color.primary.opacity(0.1), lineWidth: 1.5))
            .padding(.horizontal, 24)
            .padding(.bottom, 16)
            
            // Bouton d'Abonnement
            Button(action: onDismiss) {
                Text("Upgrade Now")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(Color(.systemBackground))
                    .frame(maxWidth: .infinity)
                    .frame(height: 48)
                    .background(Capsule().fill(Color.primary))
            }
            .padding(.horizontal, 24)
            
            // Footer légal
            Text("Cancel anytime. Terms & Privacy Apply.")
                .font(.system(size: 10))
                .foregroundColor(.secondary.opacity(0.7))
                .padding(.top, 14)
                .padding(.bottom, 16)
        }
    }
}

struct PaywallFeatureRow: View {
    let icon: String
    let text: String
    
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.secondary)
                .frame(width: 28, height: 28)
                .background(Circle().fill(Color.black.opacity(0.03)))
            
            Text(text)
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(.primary)
            
            Spacer()
        }
    }
}

// Couleurs utilitaires pour le badge d'urgence du Paywall
extension Color {
    static let amberLight = Color(red: 254/255, green: 243/255, blue: 199/255)
    static let amberDark = Color(red: 180/255, green: 83/255, blue: 9/255)
}

// ==========================================
// 3. L'ÉCRAN D'ENREGISTREMENT LIVE (SCREEN 6)
// ==========================================
struct ActiveRecordingView: View {
    @ObservedObject var audioManager: AudioManager
    @State private var pulseScale: CGFloat = 1.0
    
    var body: some View {
        ZStack {
            // Fond sombre profond et mystérieux
            Color(red: 0.05, green: 0.05, blue: 0.07)
                .ignoresSafeArea()
            
            // Halo lumineux en arrière-plan pour simuler l'effet de studio 3D
            Circle()
                .fill(Color.blue.opacity(0.12))
                .frame(width: 300, height: 300)
                .blur(radius: 60)
                .offset(y: -50)
            
            VStack(spacing: 0) {
                // Header d'enregistrement actif
                HStack {
                    HStack(spacing: 8) {
                        Circle()
                            .fill(Color.red)
                            .frame(width: 6, height: 6)
                            .opacity(pulseScale == 1.0 ? 0.4 : 1.0)
                        Text("LIVE RECORDING")
                            .font(.system(size: 10, weight: .bold))
                            .tracking(1)
                            .foregroundColor(.white.opacity(0.6))
                    }
                    Spacer()
                    Button(action: { audioManager.stopRecording() }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.white.opacity(0.6))
                            .frame(width: 32, height: 32)
                            .background(Circle().fill(Color.white.opacity(0.06)))
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 20)
                
                Spacer()
                
                // Visuel central de l'Orbe 3D Lumineux
                ZStack {
                    // Pulsation en arrière-plan
                    Circle()
                        .stroke(Color.white.opacity(0.05), lineWidth: 1)
                        .frame(width: 260, height: 260)
                        .scaleEffect(pulseScale)
                    
                    Circle()
                        .stroke(Color.white.opacity(0.02), lineWidth: 1)
                        .frame(width: 310, height: 310)
                        .scaleEffect(pulseScale + 0.15)
                    
                    Image("recording_orb")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                        .shadow(color: Color.blue.opacity(0.3), radius: 30, x: 0, y: 10)
                }
                .padding(.bottom, 50)
                .onAppear {
                    withAnimation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true)) {
                        pulseScale = 1.15
                    }
                }
                
                // Chronomètre
                Text(String(format: "%02d:%02d", Int(audioManager.elapsedTime) / 60, Int(audioManager.elapsedTime) % 60))
                    .font(.system(size: 42, weight: .light, design: .serif))
                    .foregroundColor(.white)
                
                Text("Analyzing voice patterns...")
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.4))
                    .padding(.top, 8)
                
                Spacer()
                
                // Bouton Stop Carré de fin de session
                VStack(spacing: 12) {
                    Button(action: { audioManager.stopRecording() }) {
                        Circle()
                            .fill(Color.white.opacity(0.08))
                            .frame(width: 72, height: 72)
                            .overlay(
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.red)
                                    .frame(width: 18, height: 18)
                            )
                            .overlay(
                                Circle().stroke(Color.white.opacity(0.12), lineWidth: 1)
                            )
                    }
                    
                    Text("TAP TO END SESSION")
                        .font(.system(size: 9, weight: .bold))
                        .tracking(1)
                        .foregroundColor(.white.opacity(0.4))
                }
                .padding(.bottom, 30)
            }
        }
    }
}

// ==========================================
// 4. MODALE DES DÉTAILS DE L'ANALYSE
// ==========================================
// ==========================================
// 4. MODALE DES DÉTAILS AVEC CHAT INTÉGRÉ
// ==========================================
// ==========================================
// 4. MODALE DES DÉTAILS AVEC CHAT INTÉGRÉ (FIXED)
// ==========================================
struct DetailView: View {
    let recording: Recording
    @Environment(\.dismiss) var dismiss

    @State private var selectedTab = 0
    @StateObject private var chatVM: NoteChatViewModel
    @StateObject private var playbackManager = AudioPlaybackManager()

    init(recording: Recording) {
        self.recording = recording
        _chatVM = StateObject(wrappedValue: NoteChatViewModel(recording: recording))
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                if recording.fileURL != nil {
                    AudioPlayerBar(playbackManager: playbackManager, recording: recording)
                        .padding(.horizontal, 24)
                        .padding(.top, 8)
                        .onAppear {
                            if let url = recording.fileURL {
                                playbackManager.load(url: url)
                            }
                        }
                        .onDisappear {
                            playbackManager.stop()
                        }
                }

                HStack(spacing: 0) {
                    TabButton(title: "Overview", isSelected: selectedTab == 0) {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                            selectedTab = 0
                        }
                    }
                    TabButton(title: "Transcript", isSelected: selectedTab == 1) {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                            selectedTab = 1
                        }
                    }
                    TabButton(title: "Ask AI", isSelected: selectedTab == 2) {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                            selectedTab = 2
                        }
                    }
                }
                .padding(4)
                .background(Color(.systemGray6))
                .cornerRadius(12)
                .padding(.horizontal, 24)
                .padding(.vertical, 16)

                VStack(spacing: 0) {
                    if selectedTab == 0 {
                        ScrollView {
                            VStack(alignment: .leading, spacing: 24) {
                                Text(recording.summary)
                                    .font(.system(size: 15))
                                    .lineSpacing(6)
                                    .padding()
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .background(Color(.secondarySystemBackground))
                                    .cornerRadius(16)

                                Text("Key Takeaways")
                                    .font(.system(size: 18, weight: .bold, design: .serif))

                                ForEach(recording.takeaways) { item in
                                    HStack(alignment: .top, spacing: 12) {
                                        Text("•").font(.title3).foregroundColor(.primary)
                                        Text(item.text).font(.system(size: 14)).foregroundColor(.secondary).lineSpacing(4)
                                    }
                                }
                            }
                            .padding(24)
                        }
                        .transition(.asymmetric(
                            insertion: .move(edge: .leading).combined(with: .opacity),
                            removal: .move(edge: .leading).combined(with: .opacity)
                        ))
                    } else if selectedTab == 1 {
                        ScrollView {
                            VStack(alignment: .leading, spacing: 16) {
                                ForEach(recording.transcript) { segment in
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text(segment.speaker.uppercased())
                                            .font(.system(size: 10, weight: .bold))
                                            .foregroundColor(.secondary)
                                        Text(segment.text)
                                            .font(.system(size: 14))
                                            .lineSpacing(5)
                                            .foregroundColor(.primary)
                                    }
                                    .padding(16)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .background(Color(.secondarySystemBackground))
                                    .cornerRadius(16)
                                }
                            }
                            .padding(24)
                        }
                        .transition(.asymmetric(
                            insertion: .move(edge: .trailing).combined(with: .opacity),
                            removal: .move(edge: .trailing).combined(with: .opacity)
                        ))
                    } else {
                        VStack(spacing: 0) {
                            ScrollViewReader { proxy in
                                ScrollView {
                                    LazyVStack(spacing: 16) {
                                        ForEach(chatVM.messages) { msg in
                                            ChatBubbleView(message: msg)
                                                .id(msg.id)
                                        }
                                        if chatVM.isTyping {
                                            HStack {
                                                Text("AI is thinking...")
                                                    .font(.system(size: 12, weight: .medium))
                                                    .foregroundColor(.secondary)
                                                    .padding(.horizontal, 16)
                                                    .padding(.vertical, 10)
                                                    .background(Color(.systemGray6))
                                                    .cornerRadius(16)
                                                Spacer()
                                            }
                                            .padding(.horizontal, 24)
                                            .id("typingIndicator")
                                        }
                                    }
                                    .padding(.vertical, 20)
                                }
                                .onChange(of: chatVM.messages) { _ in
                                    withAnimation { proxy.scrollTo(chatVM.messages.last?.id, anchor: .bottom) }
                                }
                                .onChange(of: chatVM.isTyping) { isTyping in
                                    if isTyping {
                                        withAnimation { proxy.scrollTo("typingIndicator", anchor: .bottom) }
                                    }
                                }
                            }
                            
                            Spacer(minLength: 0) // Garantit que l'UI s'adapte proprement au clavier
                            
                            // Zone de saisie (TextField isolée des gestes parasites)
                            HStack(spacing: 12) {
                                TextField("Ask something about this note...", text: $chatVM.inputText)
                                    .font(.system(size: 14))
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 12)
                                    .background(Color(.systemGray6))
                                    .cornerRadius(20)
                                    .onSubmit { chatVM.sendMessage() }
                                
                                Button(action: { chatVM.sendMessage() }) {
                                    Image(systemName: "arrow.up")
                                        .font(.system(size: 14, weight: .bold))
                                        .foregroundColor(.white)
                                        .frame(width: 36, height: 36)
                                        .background(chatVM.inputText.isEmpty ? Color.gray : Color.primary)
                                        .clipShape(Circle())
                                }
                                .disabled(chatVM.inputText.isEmpty)
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .background(Color(.systemBackground))
                        }
                        .transition(.asymmetric(
                            insertion: .move(edge: .trailing).combined(with: .opacity),
                            removal: .move(edge: .trailing).combined(with: .opacity)
                        ))
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .navigationTitle(recording.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                        .font(.system(size: 14, weight: .bold))
                }
            }
        }
    }
}

// Composants UI de support pour le Chat
struct TabButton: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(isSelected ? .primary : .secondary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(isSelected ? Color(.systemBackground) : Color.clear)
                .cornerRadius(10)
                .shadow(color: isSelected ? Color.black.opacity(0.04) : .clear, radius: 4, x: 0, y: 2)
        }
    }
}

struct ChatBubbleView: View {
    let message: ChatMessage
    
    var body: some View {
        HStack {
            if message.isUser { Spacer() }
            
            Text(message.text)
                .font(.system(size: 14))
                .lineSpacing(4)
                .foregroundColor(message.isUser ? .white : .primary)
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(message.isUser ? Color.primary : Color(.secondarySystemBackground))
                .cornerRadius(18)
                .clipShape(BubbleShape(isUser: message.isUser))
            
            if !message.isUser { Spacer() }
        }
        .padding(.horizontal, 24)
    }
}

struct BubbleShape: Shape {
    let isUser: Bool
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: [.topLeft, .topRight, isUser ? .bottomLeft : .bottomRight], cornerRadii: CGSize(width: 18, height: 18))
        return Path(path.cgPath)
    }
}
// ==========================================
// 5. MOTEUR DU CHAT INTERACTIF "ASK YOUR NOTE"
// ==========================================
struct ChatMessage: Identifiable, Equatable {
    let id = UUID()
    let isUser: Bool
    let text: String
}

@MainActor
class NoteChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var inputText: String = ""
    @Published var isTyping: Bool = false
    
    let recording: Recording
    
    init(recording: Recording) {
        self.recording = recording
        // Message d'accueil de l'IA
        self.messages.append(ChatMessage(isUser: false, text: "Hi! I know this note well. What would you like to know?"))
    }
    
    func sendMessage() {
        let query = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return }
        
        // 1. Ajouter le message de l'utilisateur
        let userMsg = ChatMessage(isUser: true, text: query)
        messages.append(userMsg)
        inputText = ""
        isTyping = true
        Haptics.impact(.light)
        
        // 2. Préparer le contexte (La transcription complète de l'audio)
        let transcriptText = recording.transcript.map { "\($0.speaker): \($0.text)" }.joined(separator: "\n")
        
        // 3. Lancer l'appel API
        Task {
            let answer = await fetchGeminiAnswer(query: query, context: transcriptText)
            withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                self.messages.append(ChatMessage(isUser: false, text: answer))
                self.isTyping = false
                Haptics.notify(.success)
            }
        }
    }
    
    private func fetchGeminiAnswer(query: String, context: String) async -> String {
        let apiKey = Config.geminiAPIKey
        
        // Prompt envoyé à Gemini avec le contexte de la note
        let promptText = """
        You are an AI assistant. Here is the content of a voice note:
        \"\(context)\"

        Answer the following question precisely based on this note:
        \(query)
        """
        
        let urlString = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=\(apiKey)"
        guard let url = URL(string: urlString) else { return "Invalid API URL." }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let jsonBody: [String: Any] = [
            "contents": [
                [
                    "parts": [
                        ["text": promptText]
                    ]
                ]
            ]
        ]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: jsonBody)
            let (data, response) = try await URLSession.shared.data(for: request)
            
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode != 200 {
                return "Server error (\(httpResponse.statusCode)). Check your API key in Config.swift."
            }
            
            if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
               let candidates = json["candidates"] as? [[String: Any]],
               let firstCandidate = candidates.first,
               let content = firstCandidate["content"] as? [String: Any],
               let parts = content["parts"] as? [[String: Any]],
               let firstPart = parts.first,
               let text = firstPart["text"] as? String {
                return text
            }
        } catch {
            return "Connection error: \(error.localizedDescription)"
        }

        return "Could not parse the AI response."
    }
}

struct AudioPlayerBar: View {
    @ObservedObject var playbackManager: AudioPlaybackManager
    let recording: Recording

    var body: some View {
        HStack(spacing: 14) {
            Button(action: { playbackManager.togglePlayback() }) {
                Image(systemName: playbackManager.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 36, height: 36)
                    .background(Circle().fill(Color.primary))
            }

            VStack(alignment: .leading, spacing: 6) {
                ProgressView(value: playbackManager.duration > 0 ? playbackManager.currentTime / playbackManager.duration : 0)
                    .tint(.primary)

                HStack {
                    Text(formatTime(playbackManager.currentTime))
                    Spacer()
                    Text(formatTime(playbackManager.duration > 0 ? playbackManager.duration : recording.duration))
                }
                .font(.system(size: 10, weight: .medium))
                .foregroundColor(.secondary)
            }
        }
        .padding(14)
        .background(Color(.secondarySystemBackground))
        .cornerRadius(16)
    }

    private func formatTime(_ time: TimeInterval) -> String {
        let mins = Int(time) / 60
        let secs = Int(time) % 60
        return String(format: "%d:%02d", mins, secs)
    }
}
