//
//  Dasch.swift
//  NoteAI2
//
//  Created by nassr badr on 16/07/2026.
//

import SwiftUI

struct DashboardView: View {
    @ObservedObject var audioManager: AudioManager
    @State private var searchText = ""
    @State private var selectedCategory: RecordingCategory = .all
    
    private var bgPrimary: Color {
        Color(uiColor: UIColor { traitCollection in
            traitCollection.userInterfaceStyle == .dark
                ? UIColor(red: 0.05, green: 0.06, blue: 0.08, alpha: 1)
                : UIColor(red: 0.96, green: 0.97, blue: 0.98, alpha: 1)
        })
    }
    
    private var bgSecondary: Color {
        Color(uiColor: UIColor { traitCollection in
            traitCollection.userInterfaceStyle == .dark
                ? UIColor(red: 0.11, green: 0.12, blue: 0.15, alpha: 1)
                : .white
        })
    }
    
    var filteredRecordings: [Recording] {
        audioManager.recordings.filter { rec in
            let matchesSearch = searchText.isEmpty || rec.title.localizedCaseInsensitiveContains(searchText)
            let matchesCategory = selectedCategory == .all || rec.category == selectedCategory
            return matchesSearch && matchesCategory
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                bgPrimary.ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Header
                    HStack(spacing: 16) {
                        Text("Note AI")
                            .font(.system(size: 26, weight: .bold, design: .serif))
                            .foregroundColor(.primary)
                        Spacer()
                        ThemeStyleSwitch()
                        Image(systemName: "person.crop.circle.fill")
                            .resizable()
                            .frame(width: 32, height: 32)
                            .foregroundColor(.secondary)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 12)
                    
                    // Search Bar
                    HStack {
                        Image(systemName: "magnifyingglass").foregroundColor(.secondary)
                        TextField("", text: $searchText, prompt: Text("Search notes...").foregroundColor(.secondary))
                            .foregroundColor(.primary)
                    }
                    .padding(14)
                    .background(bgSecondary)
                    .cornerRadius(16)
                    .shadow(color: Color.black.opacity(0.03), radius: 8, x: 0, y: 4)
                    .padding(.horizontal, 20)
                    .padding(.top, 16)
                    
                    // Categories
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(RecordingCategory.allCases) { category in
                                Button(action: { selectedCategory = category }) {
                                    Text(category.rawValue)
                                        .font(.system(size: 13, weight: .semibold))
                                        .foregroundColor(selectedCategory == category ? Color(uiColor: .systemBackground) : .secondary)
                                        .padding(.horizontal, 16)
                                        .padding(.vertical, 8)
                                        .background(selectedCategory == category ? Color.primary : bgSecondary)
                                        .cornerRadius(20)
                                }
                            }
                        }
                        .padding(.horizontal, 20)
                    }
                    .padding(.top, 16)
                    
                    // List
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("RECENT RECORDINGS").font(.system(size: 11, weight: .bold)).foregroundColor(.secondary)
                            Spacer()
                            Image(systemName: "ellipsis").foregroundColor(.secondary)
                        }
                        .padding(.horizontal, 20).padding(.top, 24)
                        
                        ScrollView {
                            VStack(spacing: 12) {
                                if filteredRecordings.isEmpty {
                                    VStack(spacing: 8) {
                                        Image(systemName: "waveform")
                                            .font(.system(size: 28))
                                            .foregroundColor(.secondary.opacity(0.5))
                                        Text(audioManager.recordings.isEmpty ? "No recordings yet" : "No matching notes")
                                            .font(.system(size: 14, weight: .medium))
                                            .foregroundColor(.secondary)
                                        Text("Tap the mic button to capture your first note.")
                                            .font(.system(size: 12))
                                            .foregroundColor(.secondary.opacity(0.8))
                                    }
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 48)
                                } else {
                                    ForEach(filteredRecordings) { recording in
                                        Button(action: { audioManager.present(recording) }) {
                                            HStack {
                                                VStack(alignment: .leading, spacing: 6) {
                                                    Text(recording.title).font(.system(size: 15, weight: .bold)).foregroundColor(.primary)
                                                    HStack(spacing: 8) {
                                                        Text(formatDuration(recording.duration))
                                                        Text("•")
                                                        Text(formatDate(recording.createdAt))
                                                    }
                                                    .font(.system(size: 11)).foregroundColor(.secondary)
                                                }
                                                Spacer()
                                                Image(systemName: "chevron.right").font(.system(size: 14, weight: .semibold)).foregroundColor(.secondary)
                                            }
                                            .padding(16)
                                            .background(bgSecondary)
                                            .cornerRadius(18)
                                            .shadow(color: Color.black.opacity(0.03), radius: 8, x: 0, y: 4)
                                        }
                                        .contextMenu {
                                            Button(role: .destructive) {
                                                audioManager.delete(recording)
                                            } label: {
                                                Label("Delete", systemImage: "trash")
                                            }
                                        }
                                    }
                                }
                            }
                            .padding(.horizontal, 20)
                        }
                    }
                }
                
                if audioManager.isProcessing {
                    ProcessingOverlay()
                }

                // FAB Button
                VStack {
                    Spacer()
                    Button(action: { audioManager.startRecording() }) {
                        ZStack {
                            Circle().fill(Color.primary.opacity(0.15)).frame(width: 72, height: 72).blur(radius: 6)
                            Circle().fill(Color.primary).frame(width: 58, height: 58)
                            Image(systemName: "mic.fill").font(.system(size: 22, weight: .semibold)).foregroundColor(Color(uiColor: .systemBackground))
                        }
                    }
                    .padding(.bottom, 20)
                    .disabled(audioManager.isProcessing)
                    .opacity(audioManager.isProcessing ? 0.5 : 1)
                }
            }
            .navigationBarHidden(true)
            .alert("Microphone Access Needed", isPresented: $audioManager.microphonePermissionDenied) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Enable microphone access in Settings to record voice notes.")
            }
            .alert("Something Went Wrong", isPresented: Binding(
                get: { audioManager.errorMessage != nil },
                set: { if !$0 { audioManager.dismissError() } }
            )) {
                Button("OK", role: .cancel) { audioManager.dismissError() }
            } message: {
                Text(audioManager.errorMessage ?? "")
            }
            .fullScreenCover(isPresented: $audioManager.isRecording) {
                ActiveRecordingView(audioManager: audioManager)
            }
            .sheet(item: $audioManager.selectedRecording) { recording in
                DetailView(recording: recording)
            }
        }
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        let mins = Int(duration) / 60
        let secs = Int(duration) % 60
        return String(format: "%dm %02ds", mins, secs)
    }

    private func formatDate(_ date: Date) -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}

struct ProcessingOverlay: View {
    var body: some View {
        ZStack {
            Color.black.opacity(0.35).ignoresSafeArea()
            VStack(spacing: 16) {
                ProgressView()
                    .scaleEffect(1.2)
                Text("Analyzing your note...")
                    .font(.system(size: 15, weight: .semibold))
                Text("Gemini is transcribing and summarizing your recording.")
                    .font(.system(size: 12))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding(28)
            .background(.regularMaterial)
            .cornerRadius(20)
            .padding(.horizontal, 40)
        }
    }
}

struct ThemeStyleSwitch: View {
    @AppStorage("appTheme") private var appTheme: String = "system"
    
    var body: some View {
        HStack(spacing: 4) {
            ForEach([("light", "sun.max.fill"), ("system", "iphone"), ("dark", "moon.fill")], id: \.0) { theme, icon in
                Button(action: {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { appTheme = theme }
                }) {
                    Image(systemName: icon)
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(appTheme == theme ? .primary : .secondary.opacity(0.6))
                        .frame(width: 34, height: 34)
                        .background(ZStack {
                            if appTheme == theme {
                                Circle().fill(Color(uiColor: .adaptiveBackground))
                                    .shadow(color: Color.black.opacity(0.06), radius: 3, x: 0, y: 2)
                            }
                        })
                }
            }
        }
        .padding(3)
        .background(Color(uiColor: .adaptiveSegmentedControl))
        .clipShape(Capsule())
    }
}

extension UIColor {
    static let adaptiveBackground = UIColor { traitCollection in
        traitCollection.userInterfaceStyle == .dark ? UIColor(red: 0.16, green: 0.17, blue: 0.21, alpha: 1) : .white
    }
    static let adaptiveSegmentedControl = UIColor { traitCollection in
        traitCollection.userInterfaceStyle == .dark ? UIColor(red: 0.08, green: 0.09, blue: 0.11, alpha: 1) : UIColor(red: 0.92, green: 0.92, blue: 0.94, alpha: 1)
    }
}
