import Foundation

struct Config {
    // Keep your real key here locally. Do not commit Config.swift — use Config.example.swift as a template.
    static let geminiAPIKey = "YOUR_GEMINI_API_KEY_HERE"

    static var isConfigured: Bool {
        !geminiAPIKey.isEmpty && geminiAPIKey != "YOUR_GEMINI_API_KEY_HERE"
    }
}
