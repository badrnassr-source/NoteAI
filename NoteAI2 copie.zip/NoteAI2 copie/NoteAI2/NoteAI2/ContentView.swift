import SwiftUI

struct ContentView: View {
    @AppStorage("appTheme") private var appTheme: String = "system"
    // Gère si l'onboarding a déjà été vu ou non
    @AppStorage("hasCompletedOnboarding") private var hasCompletedOnboarding = false
    @StateObject private var audioManager = AudioManager()
    
    private var currentColorScheme: ColorScheme? {
        switch appTheme {
        case "light": return .light
        case "dark": return .dark
        default: return nil
        }
    }
    
    var body: some View {
        Group {
            if !hasCompletedOnboarding {
                OnboardingFlow(onCompletion: {
                    withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                        hasCompletedOnboarding = true
                    }
                })
                .preferredColorScheme(.light) // L'onboarding est blanc/lumineux comme sur ton screen
            } else {
                DashboardView(audioManager: audioManager)
                    .preferredColorScheme(currentColorScheme)
            }
        }
    }
}
