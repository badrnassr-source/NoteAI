import SwiftUI

@main
struct NoteAI2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
