//
//  AudioManager.swift
//  NoteAI2
//

import Foundation
import AVFoundation
import Combine
import SwiftUI

enum RecordingState: Equatable {
    case idle
    case recording
    case processing
    case success(Recording)

    static func == (lhs: RecordingState, rhs: RecordingState) -> Bool {
        switch (lhs, rhs) {
        case (.idle, .idle), (.recording, .recording), (.processing, .processing):
            return true
        case (.success(let a), .success(let b)):
            return a.id == b.id
        default:
            return false
        }
    }
}

@MainActor
final class AudioManager: NSObject, ObservableObject {
    @Published private(set) var state: RecordingState = .idle
    @Published private(set) var elapsedTime: TimeInterval = 0
    @Published private(set) var audioLevel: CGFloat = 0
    @Published var microphonePermissionDenied = false
    @Published var recordings: [Recording] = []
    @Published var errorMessage: String?

    @Published var isRecording = false
    @Published var selectedRecording: Recording?

    private var recorder: AVAudioRecorder?
    private var meterTimer: Timer?
    private var clockTimer: Timer?
    private var recordingURL: URL?
    private var startDate: Date?
    private let levelSmoothing: CGFloat = 0.35

    override init() {
        super.init()
        recordings = RecordingStore.load()
        configureAudioSessionNotifications()
    }

    var isProcessing: Bool {
        if case .processing = state { return true }
        return false
    }

    func startRecording() {
        Haptics.impact(.medium)
        errorMessage = nil

        guard Config.isConfigured else {
            errorMessage = "Add your Gemini API key in Config.swift before recording."
            return
        }

        switch AVAudioSession.sharedInstance().recordPermission {
        case .granted:
            beginCapture()
        case .undetermined:
            AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                Task { @MainActor in
                    if granted {
                        self?.beginCapture()
                    } else {
                        self?.microphonePermissionDenied = true
                    }
                }
            }
        case .denied:
            microphonePermissionDenied = true
        @unknown default:
            microphonePermissionDenied = true
        }
    }

    func stopRecording() {
        Haptics.impact(.medium)
        recorder?.stop()
        invalidateTimers()
        let duration = elapsedTime
        let url = recordingURL
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)

        withAnimation(.easeInOut(duration: 0.4)) {
            state = .processing
            isRecording = false
        }
        processRecording(duration: duration, fileURL: url)
    }

    func resetToIdle() {
        withAnimation(.easeInOut(duration: 0.4)) {
            state = .idle
            isRecording = false
            selectedRecording = nil
            elapsedTime = 0
            audioLevel = 0
        }
    }

    func present(_ recording: Recording) {
        withAnimation(.easeInOut(duration: 0.35)) {
            state = .success(recording)
            selectedRecording = recording
        }
    }

    func delete(_ recording: Recording) {
        RecordingStore.delete(recording)
        recordings.removeAll { $0.id == recording.id }
        if selectedRecording?.id == recording.id {
            selectedRecording = nil
            resetToIdle()
        }
    }

    func dismissError() {
        errorMessage = nil
    }

    private func beginCapture() {
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(.playAndRecord, mode: .default, options: [.allowBluetooth, .defaultToSpeaker, .mixWithOthers])
            try session.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            errorMessage = "Could not start the audio session."
            return
        }

        recordingURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("recording-\(UUID().uuidString).m4a")

        let settings: [String: Any] = [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: 44_100,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]

        guard let recordingURL else {
            errorMessage = "Could not create a recording file."
            return
        }

        do {
            recorder = try AVAudioRecorder(url: recordingURL, settings: settings)
            recorder?.delegate = self
            recorder?.isMeteringEnabled = true
            recorder?.prepareToRecord()
            recorder?.record()
        } catch {
            errorMessage = "Could not start recording."
            return
        }

        startDate = Date()
        elapsedTime = 0
        audioLevel = 0
        withAnimation(.easeInOut(duration: 0.4)) {
            state = .recording
            isRecording = true
        }
        startTimers()
    }

    private func startTimers() {
        meterTimer = Timer.scheduledTimer(withTimeInterval: 1.0 / 30.0, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.pollMeter() }
        }
        clockTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tickClock() }
        }
    }

    private func invalidateTimers() {
        meterTimer?.invalidate()
        meterTimer = nil
        clockTimer?.invalidate()
        clockTimer = nil
    }

    private func tickClock() {
        guard let startDate else { return }
        elapsedTime = Date().timeIntervalSince(startDate)
    }

    private func pollMeter() {
        guard let recorder, recorder.isRecording else { return }
        recorder.updateMeters()
        let power = recorder.averagePower(forChannel: 0)
        let minDb: Float = -50
        let clamped = max(power, minDb)
        let normalized = CGFloat((clamped - minDb) / abs(minDb))
        audioLevel = audioLevel + (pow(normalized, 0.6) - audioLevel) * levelSmoothing
    }

    private func processRecording(duration: TimeInterval, fileURL: URL?) {
        guard let fileURL else {
            failProcessing(with: "Recording file was missing.")
            return
        }

        Task {
            guard let audioFileName = RecordingStore.persistAudio(from: fileURL) else {
                failProcessing(with: "Could not save the recording.")
                return
            }

            let persistedURL = RecordingStore.recordingsDirectory.appendingPathComponent(audioFileName)
            guard let audioData = try? Data(contentsOf: persistedURL) else {
                failProcessing(with: "Could not read the saved recording.")
                return
            }

            do {
                let result = try await analyzeRecording(
                    audioData: audioData,
                    duration: duration,
                    audioFileName: audioFileName
                )
                recordings.insert(result, at: 0)
                RecordingStore.save(recordings)
                Haptics.notify(.success)
                withAnimation(.easeInOut(duration: 0.5)) {
                    state = .success(result)
                    selectedRecording = result
                }
            } catch {
                try? FileManager.default.removeItem(at: persistedURL)
                failProcessing(with: error.localizedDescription)
            }
        }
    }

    private func failProcessing(with message: String) {
        Haptics.notify(.error)
        errorMessage = message
        resetToIdle()
    }

    private func analyzeRecording(
        audioData: Data,
        duration: TimeInterval,
        audioFileName: String
    ) async throws -> Recording {
        let apiKey = Config.geminiAPIKey
        let base64Audio = audioData.base64EncodedString()
        let urlString = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=\(apiKey)"

        guard let url = URL(string: urlString) else {
            throw GeminiError.invalidURL
        }

        let prompt = """
        Analyze this audio recording and respond STRICTLY in the following JSON format (no markdown, no extra text):
        {
          "title": "Short synthetic title (3 to 5 words max)",
          "summary": "Smooth 2-sentence summary of the content",
          "takeaways": ["Key point 1", "Key point 2"],
          "transcript": "Full transcription of what was said",
          "category": "idea"
        }

        For category, use exactly one of: "idea", "work", or "personal".
        """

        let jsonBody: [String: Any] = [
            "contents": [
                [
                    "parts": [
                        [
                            "inline_data": [
                                "mime_type": "audio/m4a",
                                "data": base64Audio
                            ]
                        ],
                        ["text": prompt]
                    ]
                ]
            ]
        ]

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: jsonBody)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw GeminiError.invalidResponse
        }

        guard httpResponse.statusCode == 200 else {
            throw GeminiError.serverError(httpResponse.statusCode)
        }

        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let candidates = json["candidates"] as? [[String: Any]],
              let firstCandidate = candidates.first,
              let content = firstCandidate["content"] as? [String: Any],
              let parts = content["parts"] as? [[String: Any]],
              let firstPart = parts.first,
              let rawText = firstPart["text"] as? String else {
            throw GeminiError.invalidResponse
        }

        let cleanedJson = rawText
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard let parsedData = cleanedJson.data(using: .utf8),
              let dict = try JSONSerialization.jsonObject(with: parsedData) as? [String: Any] else {
            throw GeminiError.parsingFailed
        }

        let title = dict["title"] as? String ?? "Voice Note"
        let summary = dict["summary"] as? String ?? "Analysis completed."
        let takeawaysArray = dict["takeaways"] as? [String] ?? []
        let transcriptText = dict["transcript"] as? String ?? ""
        let category = RecordingCategory.fromAIValue(dict["category"] as? String ?? "idea")

        return Recording(
            title: title,
            duration: duration,
            category: category,
            audioFileName: audioFileName,
            summary: summary,
            takeaways: takeawaysArray.map { KeyTakeaway(text: $0) },
            transcript: [TranscriptSegment(speaker: "Me", text: transcriptText, timestamp: 0)],
            createdAt: Date()
        )
    }

    private func configureAudioSessionNotifications() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleInterruption),
            name: AVAudioSession.interruptionNotification,
            object: AVAudioSession.sharedInstance()
        )
    }

    @objc nonisolated private func handleInterruption(_ notification: Notification) {
        guard let userInfo = notification.userInfo,
              let typeValue = userInfo[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: typeValue) else { return }

        Task { @MainActor in
            switch type {
            case .began where isRecording:
                errorMessage = "Recording stopped because another app used the microphone."
                stopRecording()
            case .ended:
                break
            @unknown default:
                break
            }
        }
    }
}

extension AudioManager: AVAudioRecorderDelegate {}

enum GeminiError: LocalizedError {
    case invalidURL
    case invalidResponse
    case parsingFailed
    case serverError(Int)

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Invalid API URL."
        case .invalidResponse:
            return "Unexpected response from Gemini."
        case .parsingFailed:
            return "Could not parse the AI response."
        case .serverError(let code):
            return "Gemini server error (\(code)). Check your API key in Config.swift."
        }
    }
}
