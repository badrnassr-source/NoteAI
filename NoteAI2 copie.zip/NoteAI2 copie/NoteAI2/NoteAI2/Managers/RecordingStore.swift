//
//  RecordingStore.swift
//  NoteAI2
//

import Foundation

enum RecordingStore {
    static let recordingsDirectory: URL = {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let directory = documents.appendingPathComponent("Recordings", isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory
    }()

    private static var indexURL: URL {
        recordingsDirectory.appendingPathComponent("recordings.json")
    }

    static func load() -> [Recording] {
        guard let data = try? Data(contentsOf: indexURL),
              let recordings = try? JSONDecoder().decode([Recording].self, from: data) else {
            return []
        }
        return recordings.sorted { $0.createdAt > $1.createdAt }
    }

    static func save(_ recordings: [Recording]) {
        guard let data = try? JSONEncoder().encode(recordings) else { return }
        try? data.write(to: indexURL, options: .atomic)
    }

    static func persistAudio(from temporaryURL: URL) -> String? {
        let fileName = "recording-\(UUID().uuidString).m4a"
        let destination = recordingsDirectory.appendingPathComponent(fileName)
        do {
            if FileManager.default.fileExists(atPath: destination.path) {
                try FileManager.default.removeItem(at: destination)
            }
            try FileManager.default.moveItem(at: temporaryURL, to: destination)
            return fileName
        } catch {
            return nil
        }
    }

    static func delete(_ recording: Recording) {
        var recordings = load()
        recordings.removeAll { $0.id == recording.id }
        save(recordings)

        if let fileURL = recording.fileURL {
            try? FileManager.default.removeItem(at: fileURL)
        }
    }
}
