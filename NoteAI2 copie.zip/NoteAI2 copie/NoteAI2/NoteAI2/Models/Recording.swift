//
//  Recording.swift
//  NoteAI2
//

import Foundation

enum RecordingCategory: String, CaseIterable, Identifiable, Codable {
    case all = "All"
    case idea = "Ideas"
    case work = "Work"
    case personal = "Personal"

    var id: String { rawValue }

    static func fromAIValue(_ value: String) -> RecordingCategory {
        switch value.lowercased() {
        case "work": return .work
        case "personal": return .personal
        default: return .idea
        }
    }
}

struct KeyTakeaway: Identifiable, Codable, Equatable {
    var id = UUID()
    let text: String
}

struct TranscriptSegment: Identifiable, Codable, Equatable {
    var id = UUID()
    let speaker: String
    let text: String
    let timestamp: TimeInterval
}

struct Recording: Identifiable, Equatable, Codable {
    var id = UUID()
    let title: String
    let duration: TimeInterval
    let category: RecordingCategory
    let audioFileName: String?
    let summary: String
    let takeaways: [KeyTakeaway]
    let transcript: [TranscriptSegment]
    let createdAt: Date

    var fileURL: URL? {
        guard let audioFileName else { return nil }
        return RecordingStore.recordingsDirectory.appendingPathComponent(audioFileName)
    }
}

extension Recording {
    static var mock: [Recording] {
        [
            Recording(
                title: "Chrome Extension Idea",
                duration: 45,
                category: .idea,
                audioFileName: nil,
                summary: "Discussion around a smart voice transcription Chrome extension powered by the Gemini API.",
                takeaways: [
                    KeyTakeaway(text: "Use Manifest V3 architecture."),
                    KeyTakeaway(text: "Handle local audio as Base64 payload."),
                    KeyTakeaway(text: "Integrate a keyboard shortcut system.")
                ],
                transcript: [
                    TranscriptSegment(speaker: "Me", text: "I should build a fast Chrome extension to transcribe my voice memos in one click.", timestamp: 0)
                ],
                createdAt: Date().addingTimeInterval(-3600)
            ),
            Recording(
                title: "Linear Algebra Review",
                duration: 120,
                category: .work,
                audioFileName: nil,
                summary: "Course notes on matrix inversion and validating vector spaces.",
                takeaways: [
                    KeyTakeaway(text: "Verify linear independence conditions."),
                    KeyTakeaway(text: "Review Gaussian elimination method.")
                ],
                transcript: [
                    TranscriptSegment(speaker: "Professor", text: "A family of vectors is free if the only zero linear combination has zero coefficients.", timestamp: 0)
                ],
                createdAt: Date().addingTimeInterval(-86400)
            )
        ]
    }
}
