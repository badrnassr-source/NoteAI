

import Foundation

struct Config {
    static let geminiAPIKey = "YOUR_GEMINI_API_KEY_HERE"

    static var isConfigured: Bool {
        !geminiAPIKey.isEmpty && geminiAPIKey != "YOUR_GEMINI_API_KEY_HERE"
    }
}
